import React from 'react';
import { Search, Sparkles, TrendingUp, Users, BookOpen, Target, Construction, Rocket, Wrench } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import SkillCard from './components/SkillCard';
import FeaturedUsers from './components/FeaturedUsers';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white relative">
      {/* Development Banner */}
      <div className="bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 text-white text-center py-1 text-sm">
        <div className="flex items-center justify-center gap-2">
          <Construction className="h-4 w-4" />
          <span>Preview Version - Under Active Development</span>
          <Wrench className="h-4 w-4 animate-spin-slow" />
        </div>
      </div>

      <Navbar />
      <Hero />
      
      {/* Fun Decorative Elements */}
      <div className="absolute top-40 right-10 animate-bounce-slow">
        <Rocket className="h-8 w-8 text-blue-400 opacity-50" />
      </div>
      <div className="absolute top-60 left-10 animate-pulse">
        <Construction className="h-6 w-6 text-yellow-400 opacity-50" />
      </div>

      {/* Featured Skills Section */}
      <section className="max-w-7xl mx-auto px-4 py-16 relative">
        <div className="absolute -top-10 right-0 transform rotate-12">
          <div className="bg-yellow-100 text-yellow-800 px-4 py-1 rounded-full text-sm font-medium inline-flex items-center gap-2">
            <Wrench className="h-4 w-4" />
            More skills coming soon!
          </div>
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-8">Popular Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <SkillCard
            title="Web Development"
            description="Learn modern web development techniques from experienced developers"
            image="https://images.unsplash.com/photo-1593720213428-28a5b9e94613?auto=format&fit=crop&q=80"
            count={234}
          />
          <SkillCard
            title="Graphic Design"
            description="Master the fundamentals of design with professional designers"
            image="https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&q=80"
            count={189}
          />
          <SkillCard
            title="Digital Marketing"
            description="Understand modern marketing strategies and techniques"
            image="https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?auto=format&fit=crop&q=80"
            count={156}
          />
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-blue-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxjaXJjbGUgY3g9IjIwIiBjeT0iMjAiIHI9IjIiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvZz48L3N2Zz4=')] bg-repeat"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
            <div className="bg-yellow-400 text-yellow-900 px-4 py-1 rounded-full text-sm font-medium inline-flex items-center gap-2">
              <Construction className="h-4 w-4" />
              Beta Feature
            </div>
          </div>
          <h2 className="text-3xl font-bold mb-12 text-center">How SkillSwap Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Create Profile</h3>
              <p className="text-blue-200">Share your skills and what you want to learn</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Find Matches</h3>
              <p className="text-blue-200">Connect with people who complement your skills</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Start Learning</h3>
              <p className="text-blue-200">Exchange knowledge and grow together</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Track Progress</h3>
              <p className="text-blue-200">Build your portfolio and reputation</p>
            </div>
          </div>
        </div>
      </section>

      <FeaturedUsers />

      {/* Success Stories Section */}
      <section className="bg-gradient-to-r from-purple-100 to-blue-100 py-20 relative">
        <div className="absolute top-5 right-10">
          <div className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-medium inline-flex items-center gap-2 animate-pulse">
            <Construction className="h-4 w-4" />
            More stories loading...
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-gray-800 mb-12 text-center">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="flex items-center mb-6">
                <img
                  src="https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80"
                  alt="Success story"
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="text-xl font-semibold">Jessica Wang</h3>
                  <p className="text-gray-600">Learned UI/UX Design</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "Through SkillSwap, I found an amazing mentor who helped me transition into UI/UX design. 
                I was able to build my portfolio and land my dream job within 6 months!"
              </p>
              <div className="flex items-center text-yellow-400">
                <Sparkles className="w-5 h-5 mr-2" />
                <span className="text-gray-700">Now working at Google</span>
              </div>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-md">
              <div className="flex items-center mb-6">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80"
                  alt="Success story"
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="text-xl font-semibold">David Kim</h3>
                  <p className="text-gray-600">Learned Web Development</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "I exchanged my marketing expertise for web development lessons. 
                The practical experience and mentorship I received were invaluable for my career switch."
              </p>
              <div className="flex items-center text-yellow-400">
                <Sparkles className="w-5 h-5 mr-2" />
                <span className="text-gray-700">Launched successful startup</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white py-20 relative">
        <div className="absolute bottom-5 left-10">
          <div className="bg-green-100 text-green-800 px-4 py-1 rounded-full text-sm font-medium inline-flex items-center gap-2">
            <Wrench className="h-4 w-4" />
            Early access coming soon
          </div>
        </div>
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">
            Ready to Start Your Learning Journey?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join thousands of people who are already exchanging skills and growing together.
          </p>
          <button className="bg-blue-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-blue-700 transition transform hover:scale-105">
            Get Started Now
          </button>
        </div>
      </section>
    </div>
  );
}

export default App;