import React from 'react';
import { Users } from 'lucide-react';

interface SkillCardProps {
  title: string;
  description: string;
  image: string;
  count: number;
}

const SkillCard: React.FC<SkillCardProps> = ({ title, description, image, count }) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105">
      <div className="h-48 w-full overflow-hidden">
        <img
          className="w-full h-full object-cover"
          src={image}
          alt={title}
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="flex items-center text-blue-600">
          <Users size={20} className="mr-2" />
          <span>{count} members</span>
        </div>
      </div>
    </div>
  );
};

export default SkillCard;