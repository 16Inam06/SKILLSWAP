import React from 'react';
import { Search, Construction, Rocket } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-24">
      {/* Development Indicator */}
      <div className="absolute top-0 left-1/2 transform -translate-x-1/2">
        <div className="bg-yellow-400 text-yellow-900 px-4 py-1 rounded-full text-sm font-medium inline-flex items-center gap-2">
          <Construction className="h-4 w-4" />
          Beta Version 0.1
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Exchange Skills, Grow Together
          </h1>
          <p className="text-xl md:text-2xl mb-12 text-blue-100">
            Connect with people who want to learn what you know and teach what you want to learn
          </p>

          {/* Search Bar */}
          <div className="relative max-w-2xl mx-auto">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-4 border border-transparent rounded-full text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-lg shadow-lg"
              placeholder="Search for skills or mentors..."
            />
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
              <span className="text-sm text-gray-400">(Demo Mode)</span>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative">
              <div className="text-4xl font-bold">10,000+</div>
              <div className="text-blue-200">Active Members</div>
              <div className="text-xs text-blue-300 mt-1">(Simulated Data)</div>
            </div>
            <div>
              <div className="text-4xl font-bold">500+</div>
              <div className="text-blue-200">Skills Available</div>
              <div className="text-xs text-blue-300 mt-1">(Growing Daily)</div>
            </div>
            <div>
              <div className="text-4xl font-bold">5,000+</div>
              <div className="text-blue-200">Successful Exchanges</div>
              <div className="text-xs text-blue-300 mt-1">(Beta Testing)</div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-10 right-10 animate-bounce-slow">
        <Rocket className="h-8 w-8 text-blue-300 opacity-50" />
      </div>
    </div>
  );
};

export default Hero;