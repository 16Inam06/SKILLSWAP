import React from 'react';
import { Star } from 'lucide-react';

const FeaturedUsers = () => {
  const users = [
    {
      name: 'Sarah Chen',
      title: 'UX Designer',
      skills: ['UI/UX Design', 'Figma', 'User Research'],
      rating: 4.9,
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80',
    },
    {
      name: 'Michael Rodriguez',
      title: 'Full Stack Developer',
      skills: ['React', 'Node.js', 'Python'],
      rating: 4.8,
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80',
    },
    {
      name: 'Emily Thompson',
      title: 'Digital Marketing Specialist',
      skills: ['SEO', 'Content Strategy', 'Social Media'],
      rating: 4.7,
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80',
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold text-gray-800 mb-8">Featured Mentors</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {users.map((user, index) => (
          <div key={index} className="bg-white rounded-xl shadow-md p-6">
            <div className="flex items-center mb-4">
              <img
                src={user.image}
                alt={user.name}
                className="w-16 h-16 rounded-full object-cover mr-4"
              />
              <div>
                <h3 className="text-xl font-semibold text-gray-800">{user.name}</h3>
                <p className="text-gray-600">{user.title}</p>
              </div>
            </div>
            <div className="mb-4">
              <div className="flex items-center mb-2">
                <Star className="w-5 h-5 text-yellow-400 fill-current" />
                <span className="ml-2 text-gray-700">{user.rating}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {user.skills.map((skill, skillIndex) => (
                  <span
                    key={skillIndex}
                    className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
              Connect
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};

export default FeaturedUsers;