import React from 'react';
import { Menu, X, BookOpen, Users } from 'lucide-react';
import SignInModal from './SignInModal';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [isSignInModalOpen, setIsSignInModalOpen] = React.useState(false);

  return (
    <>
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <span className="text-2xl font-bold text-blue-600">SkillSwap</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                <BookOpen size={20} />
                Learn
              </a>
              <a href="#" className="text-gray-600 hover:text-blue-600 flex items-center gap-2">
                <Users size={20} />
                Community
              </a>
              <button 
                onClick={() => setIsSignInModalOpen(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition"
              >
                Sign In
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-gray-600 hover:text-blue-600"
              >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isOpen && (
            <div className="md:hidden">
              <div className="pt-2 pb-3 space-y-1">
                <a
                  href="#"
                  className="block px-3 py-2 text-gray-600 hover:text-blue-600"
                >
                  Learn
                </a>
                <a
                  href="#"
                  className="block px-3 py-2 text-gray-600 hover:text-blue-600"
                >
                  Community
                </a>
                <button 
                  onClick={() => {
                    setIsSignInModalOpen(true);
                    setIsOpen(false);
                  }}
                  className="w-full text-left block px-3 py-2 text-gray-600 hover:text-blue-600"
                >
                  Sign In
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      <SignInModal 
        isOpen={isSignInModalOpen} 
        onClose={() => setIsSignInModalOpen(false)} 
      />
    </>
  );
};

export default Navbar;